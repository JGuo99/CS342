import java.util.Iterator;

public interface CreateIterator<I> {
	Iterator<I> createIterator();
}
