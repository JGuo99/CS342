/*
 * Jeff Guo
 * sguo35
 * sguo35 at uic dot edu
 * Simplified version of stack and queue data structure
 * using singly linked list.
 */

public class GLProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello generic lists");
	}

}
