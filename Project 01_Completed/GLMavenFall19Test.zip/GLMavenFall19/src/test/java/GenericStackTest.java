import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class GenericStackTest {

	static GenericStack<Integer> x;
	
	@BeforeEach
	static void setup() {
		x = new GenericStack<Integer>(5);
	}
	
	@Test
	void PushTest() {
		x.push(13);
		assertEquals(13, x.head.data, "Wrong value");
	}
}
