import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ListTest {

	GenericStack<Integer> x;
	GenericQueue<Integer> y;
	
	@BeforeEach
	void setUp() {
		x = new GenericStack<Integer>(5);
		y = new GenericQueue<Integer>(10);
	}
	
	@Test
	void PushSTest() {
		x.push(13);
		assertEquals(13, x.head.data, "Wrong value");
	}
	
	@Test
	void PushQTest() {
		y.push(26);
		assertEquals(26, y.head.data, "Wrong value");
	}
}
